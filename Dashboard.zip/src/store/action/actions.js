// import * as types from "./actiontype";
// import { apiUrl } from "../../config/config";
// import axios from "axios";
// export const getAllUsers = () => async (dispatch) => {
//   try {
//     const response = await axios.get(
//       `${apiUrl}/admin/users/getAllUsers`
//       );
//       console.log(response)
//     // if (response.data.status) {
//     //   dispatch({
//     //     type: types.ALL_USERS,
//     //     payload: response.data.data,
//     //   });
//     // } else {
//     //   console.log("fail");
//     // }
//   } catch (error) {
//     console.log(error);
//   }
// };
