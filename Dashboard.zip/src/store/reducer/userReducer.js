// import { ALL_USERS } from "../action/actiontype";

// const INITIALSTATE = { allUsers: [] };
// // All_Users: [
// //   {
// //     name: "Jason Porter",
// //     number: "+ 264-625-5858",
// //     email: "jason-porter@example.com",
// //     // image:avatar,
// //   },
// //   {
// //     name: "Jhon Wick",
// //     number: "+ 264-625-5858",
// //     email: "jason-porter@example.com",
// //     // image:avatar,
// //   },
// //   {
// //     name: "Deni Jhonson",
// //     number: "+ 264-625-5858",
// //     email: "jason-porter@example.com",
// //     // image:avatar,
// //   },
// //   {
// //     name: "Rubert Grint",
// //     number: "+ 264-625-5858",
// //     email: "jason-porter@example.com",
// //     // image:avatar,
// //   },
// // ],

// export const userReducer = (state = INITIALSTATE, action) => {
//   console.log("::::::::::::::::::::", state.allUsers);
//   switch (action.type) {
//     case ALL_USERS:
//       return {
//         ...state,
//         allUsers: action.payload,
//       };

//     default:
//       return state;
//   }
// };
