export const apiUrl  = "http://bace-110-93-244-255.ngrok.io"

export const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6OTMsInJvbGUiOjEsImlhdCI6MTY0MTI4OTk1M30.jnvNMqbmhX_Jcu56--SLE8z-U2n9fDefciBxNOU2jSc"
