import { apiUrl } from "../config/config";
import axios from "axios";


export const getAllUsers = (token) => async (dispatch) => {
    console.log(token,"pppppppppppppppppp")
  try {
    const headers = {
        'Authorization': `Bearer ${token}`
        // 'My-Custom-Header': 'foobar'
    };
    const response = await axios.get(
      `${apiUrl}/api/admin/users/getAllUsers`,{headers}
      );
      console.log("uuuuuuuuuuu")
      console.log(response.data)
    if (response.data.status) {
      dispatch({
        type: 'ALL_USERS',
        payload: response.data.data,
      });
    } else {
      console.log("fail");
    }
  } catch (error) {
    console.log(error,"-_--_---__-_--_");
  }
};
